﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjektWFA.Models;

namespace ProjektWFA
{
    public partial class ClientGUI : Form
    {
        SensorAPI api;
        
        public ClientGUI()
        {
            InitializeComponent();

            // Enter your API server instance address here:
            api = new SensorAPI(new Uri("http://172.16.226.1:5000"));

            cb_node.DataSource = api.GetNodes();
            cb_node.DisplayMember = "Name";

            cb_sensor.DataSource = api.GetSensors();
            cb_sensor.DisplayMember = "Name";

            chart_values.Series.Clear();
            chart_values.Legends.Clear();
            chart_values.Series.Add("Values");
            chart_values.ChartAreas[0].AxisX.LabelStyle.Format = "HH:mm:ss";
            updateChart();

        }

        public void updateChart(long sensor_id=1)
        {
            var values = api.GetSensorValues(sensor_id, 20);
            List<float> yvals = new List<float>();
            List<DateTime> xvals = new List<DateTime>();
            foreach (var val in values)
            {
                yvals.Add(int.Parse(val.Value) / 1000);
                xvals.Add(DateTimeOffset.FromUnixTimeSeconds((long)val.Timestamp).DateTime);
            }
            chart_values.Series["Values"].Points.DataBindXY(xvals, yvals);
            chart_values.Update();
        }

        private void bt_refresh_Click(object sender, EventArgs e)
        {
            updateChart();
        }
    }
}
