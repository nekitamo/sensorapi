﻿namespace ProjektWFA
{
    partial class ClientGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart_values = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.cb_node = new System.Windows.Forms.ComboBox();
            this.cb_sensor = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bt_refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart_values)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart_values
            // 
            chartArea3.Name = "ChartArea1";
            this.chart_values.ChartAreas.Add(chartArea3);
            this.chart_values.Dock = System.Windows.Forms.DockStyle.Fill;
            legend3.Name = "Legend1";
            this.chart_values.Legends.Add(legend3);
            this.chart_values.Location = new System.Drawing.Point(0, 0);
            this.chart_values.Name = "chart_values";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chart_values.Series.Add(series3);
            this.chart_values.Size = new System.Drawing.Size(800, 399);
            this.chart_values.TabIndex = 0;
            this.chart_values.Text = "Values";
            // 
            // cb_node
            // 
            this.cb_node.FormattingEnabled = true;
            this.cb_node.Items.AddRange(new object[] {
            "Node 1",
            "Node 2"});
            this.cb_node.Location = new System.Drawing.Point(12, 18);
            this.cb_node.Name = "cb_node";
            this.cb_node.Size = new System.Drawing.Size(121, 21);
            this.cb_node.TabIndex = 1;
            // 
            // cb_sensor
            // 
            this.cb_sensor.FormattingEnabled = true;
            this.cb_sensor.Items.AddRange(new object[] {
            "Sensor 1",
            "Sensor 2"});
            this.cb_sensor.Location = new System.Drawing.Point(148, 18);
            this.cb_sensor.Name = "cb_sensor";
            this.cb_sensor.Size = new System.Drawing.Size(121, 21);
            this.cb_sensor.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bt_refresh);
            this.panel1.Controls.Add(this.cb_node);
            this.panel1.Controls.Add(this.cb_sensor);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 399);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 51);
            this.panel1.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chart_values);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 399);
            this.panel2.TabIndex = 4;
            // 
            // bt_refresh
            // 
            this.bt_refresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_refresh.Location = new System.Drawing.Point(713, 15);
            this.bt_refresh.Name = "bt_refresh";
            this.bt_refresh.Size = new System.Drawing.Size(75, 23);
            this.bt_refresh.TabIndex = 3;
            this.bt_refresh.Text = "Refresh";
            this.bt_refresh.UseVisualStyleBackColor = true;
            this.bt_refresh.Click += new System.EventHandler(this.bt_refresh_Click);
            // 
            // SensorGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "SensorGUI";
            this.Text = "SensorGUI";
            ((System.ComponentModel.ISupportInitialize)(this.chart_values)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart_values;
        private System.Windows.Forms.ComboBox cb_node;
        private System.Windows.Forms.ComboBox cb_sensor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button bt_refresh;
    }
}

